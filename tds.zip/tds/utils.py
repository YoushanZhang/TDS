"""
Common utilities used by all TDS training projects.
"""

import os
import random
from typing import Dict, List

import numpy as np
import torch
import torch.distributed as dist
import torch.nn as nn


class DropPath(nn.Module):
    """Drop paths (stochastic depth) per sample."""

    def __init__(self, drop_prob: float = 0.0):
        super().__init__()
        self.drop_prob = float(drop_prob)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if self.drop_prob == 0.0 or not self.training:
            return x
        keep_prob = 1.0 - self.drop_prob
        shape = (x.shape[0],) + (1,) * (x.ndim - 1)
        random_tensor = keep_prob + torch.rand(
            shape, dtype=x.dtype, device=x.device
        )
        random_tensor.floor_()
        return x * random_tensor / keep_prob


def setup_runtime():
    """Initialize distributed training; fall back to single GPU / CPU."""
    distributed = "RANK" in os.environ and "WORLD_SIZE" in os.environ

    if distributed:
        rank = int(os.environ["RANK"])
        world_size = int(os.environ["WORLD_SIZE"])
        local_rank = int(os.environ.get("LOCAL_RANK", 0))
        torch.cuda.set_device(local_rank)
        dist.init_process_group(backend="nccl", init_method="env://")
        device = torch.device("cuda", local_rank)
        mode = "ddp"
    else:
        rank = 0
        world_size = 1
        local_rank = 0
        if torch.cuda.is_available():
            device = torch.device("cuda", 0)
            mode = "data_parallel" if torch.cuda.device_count() > 1 else "single_gpu"
        else:
            device = torch.device("cpu")
            mode = "cpu"

    return distributed, rank, world_size, local_rank, device, mode


def cleanup_distributed():
    if dist.is_available() and dist.is_initialized():
        dist.barrier()
        dist.destroy_process_group()


def is_main_process(rank: int) -> bool:
    return rank == 0


def seed_everything(seed: int, rank: int = 0):
    seed = seed + rank
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def seed_worker(worker_id: int):
    worker_seed = torch.initial_seed() % (2**32)
    np.random.seed(worker_seed)
    random.seed(worker_seed)


def build_parameter_groups(model: nn.Module, weight_decay: float):
    """Split parameters into decay / no-decay groups."""
    decay = []
    no_decay = []
    seen = set()

    for name, parameter in model.named_parameters():
        if not parameter.requires_grad or id(parameter) in seen:
            continue
        seen.add(id(parameter))

        lower_name = name.lower()
        exclude = (
            parameter.ndim <= 1
            or name.endswith(".bias")
            or "norm" in lower_name
            or "pos_embed" in lower_name
            or "layer_scale" in lower_name
            or "a_diag" in lower_name
            or "gamma_raw" in lower_name
            or "rule_centers" in lower_name
        )
        if exclude:
            no_decay.append(parameter)
        else:
            decay.append(parameter)

    return [
        {"params": decay, "weight_decay": weight_decay},
        {"params": no_decay, "weight_decay": 0.0},
    ]


def project_stability_parameters(model: nn.Module):
    """Post-update projection to keep recurrence parameters in safe ranges."""
    with torch.no_grad():
        for module in model.modules():
            module_name = module.__class__.__name__
            if module_name == "SemanticDelayProcessor":
                module.A_diag.clamp_(0.85, 0.99)
                module.gamma_raw.clamp_(-3.0, 3.0)
            elif module_name == "FuzzySemanticSystem":
                module.rule_weights_f.clamp_(-5.0, 5.0)
                module.rule_weights_g.clamp_(-5.0, 5.0)
                module.rule_centers.clamp_(-3.0, 3.0)


@torch.no_grad()
def reduce_statistics(values: List[float], device, distributed: bool):
    tensor = torch.tensor(values, dtype=torch.float64, device=device)
    if distributed:
        dist.all_reduce(tensor, op=dist.ReduceOp.SUM)
    return tensor.cpu().tolist()


def count_parameters(model: nn.Module) -> Dict[str, int]:
    total = sum(p.numel() for p in model.parameters())
    trainable = sum(p.numel() for p in model.parameters() if p.requires_grad)
    return {"total": total, "trainable": trainable}
