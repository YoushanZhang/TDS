"""
TDS core modules.

These modules are shared across language, vision, and vision-language tasks.
The implementation here is the numerically stabilized version used in vision
training; it is therefore safe for both vision and long-sequence language
workloads.
"""

import math
from typing import Optional, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F


class SemanticLagEstimator(nn.Module):
    """
    Soft semantic lag estimator.

    Computes a soft attention distribution over the previous ``max_lag`` tokens
    and returns the weighted historical context together with a soft similarity
    score.
    """

    def __init__(
        self,
        max_lag: int,
        hidden_dim: int,
        kappa: float = 1.0,
        lambda_decay: float = 0.03,
        alpha_power: float = 1.0,
    ):
        super().__init__()
        self.max_lag = max_lag
        self.hidden_dim = hidden_dim
        self.kappa = kappa
        self.lambda_decay = lambda_decay
        self.alpha_power = alpha_power

        # self.sim_proj = nn.Linear(hidden_dim, hidden_dim, bias=False)
        self.sim_proj = nn.Linear(hidden_dim, hidden_dim)

        u = torch.arange(1, max_lag + 1).float()
        decay_weights = torch.exp(-lambda_decay * (u ** alpha_power))
        self.register_buffer("decay_weights", decay_weights)

        self.sim_threshold = nn.Parameter(torch.tensor(0.2))

    def forward(
        self,
        current_embed: torch.Tensor,
        history_embeds: torch.Tensor,
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """
        Args:
            current_embed:  [B, T, H] or [B, H]
            history_embeds: [B, T, L, H] or [B, L, H]
        Returns:
            alpha:  [B, T, L] or [B, L]
            x_hist: [B, T, H] or [B, H]
            s_soft: [B, T] or [B]
        """
        if current_embed.dim() == 3:
            batch_size, seq_len, hidden_dim = current_embed.shape
            current_flat = current_embed.reshape(-1, hidden_dim)
            history_flat = history_embeds.reshape(-1, self.max_lag, hidden_dim)

            current_proj = self.sim_proj(current_flat)
            history_proj = self.sim_proj(history_flat)

            current_norm = current_proj.norm(dim=1, keepdim=True) + 1e-8
            history_norm = history_proj.norm(dim=2) + 1e-8
            sim = (
                current_proj.unsqueeze(1) @ history_proj.transpose(1, 2)
            ).squeeze(1)
            sim = sim / (current_norm * history_norm)

            weighted_sim = sim * self.decay_weights.unsqueeze(0)
            alpha = F.softmax(self.kappa * weighted_sim, dim=1)
            x_hist = torch.einsum("bl,bld->bd", alpha, history_flat)
            x_hist = x_hist.reshape(batch_size, seq_len, hidden_dim)
            s_soft = (alpha * weighted_sim).sum(dim=1)
            s_soft = s_soft.reshape(batch_size, seq_len)
            alpha = alpha.reshape(batch_size, seq_len, self.max_lag)
        else:
            current_proj = self.sim_proj(current_embed)
            history_proj = self.sim_proj(history_embeds)

            current_norm = current_proj.norm(dim=1, keepdim=True) + 1e-8
            history_norm = history_proj.norm(dim=2) + 1e-8
            sim = (
                current_proj.unsqueeze(1) @ history_proj.transpose(1, 2)
            ).squeeze(1)
            sim = sim / (current_norm * history_norm)

            weighted_sim = sim * self.decay_weights.unsqueeze(0)
            alpha = F.softmax(self.kappa * weighted_sim, dim=1)
            x_hist = torch.einsum("bl,bld->bd", alpha, history_embeds)
            s_soft = (alpha * weighted_sim).sum(dim=1)

        return alpha, x_hist, s_soft


class FuzzySemanticSystem(nn.Module):
    """
    Fuzzy semantic system with bounded outputs.

    Returns modulation signals ``f_hat`` (bounded in [-1, 1]) and ``g_hat``
    (bounded in (0, 1)) to avoid training instabilities.
    """

    def __init__(self, hidden_dim: int, n_rules: int, sigma: float = 0.15):
        super().__init__()
        self.hidden_dim = hidden_dim
        self.n_rules = n_rules
        self.sigma = sigma

        self.rule_centers = nn.Parameter(torch.randn(n_rules, hidden_dim) * 0.1)
        self.rule_weights_f = nn.Parameter(torch.randn(n_rules))
        self.rule_weights_g = nn.Parameter(torch.randn(n_rules))

    def forward(self, z: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Args:
            z: [B, T, H] or [B, H]
        Returns:
            f_hat, g_hat: same shape as z
        """
        if z.dim() == 3:
            batch_size, seq_len, hidden_dim = z.shape
            z_expand = z.unsqueeze(2)
            centers_expand = self.rule_centers.unsqueeze(0).unsqueeze(0)
            dist = torch.norm(z_expand - centers_expand, dim=3)
            tilde_mu = torch.exp(-0.5 * (dist / self.sigma) ** 2)
            mu = tilde_mu / (tilde_mu.sum(dim=2, keepdim=True) + 1e-8)
            f_scalar = mu @ self.rule_weights_f.unsqueeze(1)
            g_scalar = mu @ self.rule_weights_g.unsqueeze(1)
            f_hat = torch.tanh(f_scalar).expand(-1, -1, hidden_dim)
            g_hat = torch.sigmoid(g_scalar).expand(-1, -1, hidden_dim)
        else:
            batch_size, hidden_dim = z.shape
            z_expand = z.unsqueeze(1)
            centers_expand = self.rule_centers.unsqueeze(0)
            dist = torch.norm(z_expand - centers_expand, dim=2)
            tilde_mu = torch.exp(-0.5 * (dist / self.sigma) ** 2)
            mu = tilde_mu / (tilde_mu.sum(dim=1, keepdim=True) + 1e-8)
            f_scalar = mu @ self.rule_weights_f.unsqueeze(1)
            g_scalar = mu @ self.rule_weights_g.unsqueeze(1)
            f_hat = torch.tanh(f_scalar).expand(-1, hidden_dim)
            g_hat = torch.sigmoid(g_scalar).expand(-1, hidden_dim)

        return f_hat, g_hat


class SemanticDelayProcessor(nn.Module):
    """
    Numerically stable semantic delay processor.

    Combines bidirectional depth-wise convolution, soft lag estimation, a fuzzy
    delay correction, and a vectorized linear recurrence.
    """

    def __init__(
        self,
        hidden_dim: int,
        max_lag: int,
        n_rules: int,
        kappa: float = 1.0,
        lambda_decay: float = 0.03,
        alpha_power: float = 1.0,
        sigma: float = 0.15,
        conv_kernel: int = 4,
        dropout: float = 0.1,
    ):
        super().__init__()
        self.hidden_dim = hidden_dim
        self.max_lag = max_lag
        self.conv_kernel = conv_kernel

        self.conv1d_forward = nn.Conv1d(
            hidden_dim,
            hidden_dim,
            kernel_size=conv_kernel,
            padding=conv_kernel - 1,
            groups=hidden_dim,
            bias=False,
        )
        self.conv1d_backward = nn.Conv1d(
            hidden_dim,
            hidden_dim,
            kernel_size=conv_kernel,
            padding=conv_kernel - 1,
            groups=hidden_dim,
            bias=False,
        )
        self.conv_activation = nn.GELU()

        self.lag_estimator = SemanticLagEstimator(
            max_lag, hidden_dim, kappa, lambda_decay, alpha_power
        )
        self.fuzzy_system = FuzzySemanticSystem(hidden_dim, n_rules, sigma)

        self.A_diag = nn.Parameter(torch.ones(hidden_dim) * 0.9)
        self.B = nn.Parameter(torch.randn(hidden_dim, hidden_dim) * 0.01)
        self.C = nn.Parameter(torch.randn(hidden_dim, hidden_dim) * 0.01)
        self.gamma_raw = nn.Parameter(torch.tensor(0.0))

        self.phi = nn.SiLU()
        self.psi = nn.Tanh()

        self.in_proj = nn.Linear(hidden_dim, hidden_dim)
        self.out_proj = nn.Linear(hidden_dim, hidden_dim)
        self.layer_norm = nn.LayerNorm(hidden_dim)
        self.dropout = nn.Dropout(dropout)

        self._init_weights()

    def _init_weights(self):
        nn.init.xavier_uniform_(self.B)
        nn.init.xavier_uniform_(self.C)

    def forward(
        self,
        x_embed: torch.Tensor,
        return_sequence: bool = False,
    ) -> torch.Tensor:
        """
        Args:
            x_embed: [B, T, H]
            return_sequence: if True return full sequence, else last state
        Returns:
            hidden_states: [B, T, H] if return_sequence else [B, H]
        """
        batch_size, seq_len, hidden_dim = x_embed.shape
        device = x_embed.device

        x_embed = x_embed.float()

        x_proj = self.in_proj(x_embed)

        x_conv_f = self.conv1d_forward(
            x_proj.transpose(1, 2)
        )[:, :, :seq_len].transpose(1, 2)
        x_conv_f = self.conv_activation(x_conv_f)

        x_backward_rev = torch.flip(x_proj, dims=[1])
        x_conv_b = self.conv1d_backward(
            x_backward_rev.transpose(1, 2)
        )[:, :, :seq_len].transpose(1, 2)
        x_conv_b = torch.flip(x_conv_b, dims=[1])
        x_conv_b = self.conv_activation(x_conv_b)

        x_conv = x_conv_f + x_conv_b

        padded_embed = torch.cat(
            [
                torch.zeros(
                    batch_size,
                    self.max_lag,
                    hidden_dim,
                    device=device,
                    dtype=x_embed.dtype,
                ),
                x_embed,
            ],
            dim=1,
        )
        history_windows = padded_embed.unfold(1, self.max_lag, 1)
        history_windows = history_windows.permute(0, 1, 3, 2)[:, :seq_len]

        _, x_hist, s_soft = self.lag_estimator(x_embed, history_windows)

        b_k = torch.matmul(x_embed + x_conv, self.B.T)
        b_k = torch.nan_to_num(b_k, nan=0.0, posinf=10.0, neginf=-10.0)

        gamma = 0.1 * torch.tanh(self.gamma_raw)
        Cx_hist = torch.matmul(x_hist, self.C.T)
        d_k = gamma * self.psi(s_soft.unsqueeze(-1) * Cx_hist)
        d_k = torch.nan_to_num(d_k, nan=0.0, posinf=1.0, neginf=-1.0)

        a = torch.clamp(self.A_diag, min=0.5, max=0.99).float()
        t = torch.arange(seq_len, device=device).float()

        log_a = torch.log(a + 1e-8).unsqueeze(0)
        log_a_pow = t.unsqueeze(1) * log_a
        a_pow = torch.exp(log_a_pow)
        a_pow_inv = torch.exp(-log_a_pow)

        b_k_clipped = torch.clamp(b_k, min=-10.0, max=10.0)
        b_scaled = b_k_clipped * a_pow_inv.unsqueeze(0)
        h_scaled = torch.cumsum(b_scaled, dim=1)
        h = h_scaled * a_pow.unsqueeze(0)
        h = torch.clamp(h, min=-100.0, max=100.0)
        h = torch.nan_to_num(h, nan=0.0, posinf=100.0, neginf=-100.0)

        z = d_k / 2.0
        f_hat, g_hat = self.fuzzy_system(z)

        hidden_states = f_hat * self.phi(h) + g_hat * d_k
        hidden_states = torch.nan_to_num(
            hidden_states, nan=0.0, posinf=10.0, neginf=-10.0
        )
        hidden_states = self.dropout(hidden_states)

        hidden_states = self.out_proj(hidden_states)
        hidden_states = self.layer_norm(hidden_states + x_embed)

        if return_sequence:
            return hidden_states
        return hidden_states[:, -1, :]


class TDSBlock(nn.Module):
    """
    TDS block with a Mamba-style gating structure.

        x -> in_proj -> split(x_proj, z_proj)
        x_proj -> Conv1d -> SiLU -> SDP
        SDP * SiLU(z_proj) -> out_proj -> dropout -> + residual
    """

    def __init__(
        self,
        hidden_dim: int,
        max_lag: int,
        n_rules: int,
        conv_kernel: int = 4,
        kappa: float = 1.0,
        lambda_decay: float = 0.03,
        alpha_power: float = 1.0,
        sigma: float = 0.15,
        expand_factor: int = 2,
        dropout: float = 0.1,
    ):
        super().__init__()
        self.hidden_dim = hidden_dim
        inner_dim = hidden_dim * expand_factor

        self.in_proj = nn.Linear(hidden_dim, inner_dim * 2, bias=False)
        self.conv1d = nn.Conv1d(
            inner_dim,
            inner_dim,
            kernel_size=conv_kernel,
            padding=conv_kernel - 1,
            groups=inner_dim,
            bias=False,
        )
        self.sdp = SemanticDelayProcessor(
            hidden_dim=inner_dim,
            max_lag=max_lag,
            n_rules=n_rules,
            kappa=kappa,
            lambda_decay=lambda_decay,
            alpha_power=alpha_power,
            sigma=sigma,
            conv_kernel=conv_kernel,
            dropout=dropout,
        )
        self.activation = nn.SiLU()
        self.out_proj = nn.Linear(inner_dim, hidden_dim, bias=False)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        residual = x
        batch_size, seq_len, hidden_dim = x.shape

        projected = self.in_proj(x)
        x_proj, z_proj = projected.chunk(2, dim=-1)

        x_conv = self.conv1d(
            x_proj.transpose(1, 2)
        )[:, :, :seq_len].transpose(1, 2)
        x_conv = self.activation(x_conv)

        x_sdp = self.sdp(x_conv, return_sequence=True)
        x_sdp = x_sdp.to(z_proj.dtype)

        x_gate = self.activation(z_proj)
        x_out = x_sdp * x_gate
        x_out = self.out_proj(x_out)
        x_out = self.dropout(x_out)

        return x_out + residual
