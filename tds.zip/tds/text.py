"""
TDS language model.

An autoregressive transformer-free language model built from TDS blocks.
"""

import math
from typing import Optional

import torch
import torch.nn as nn
import torch.nn.functional as F

from .core import TDSBlock


class TDSTextGenerator(nn.Module):
    """
    Autoregressive TDS language model.

    Parameters
    ----------
    vocab_size: size of the token vocabulary.
    hidden_dim: hidden dimension of the model.
    max_lag, n_rules: TDS core hyperparameters.
    max_seq_len: maximum supported sequence length.
    padding_idx: token id used for padding / ignored in loss.
    num_tds_blocks: number of TDS blocks.
    """

    def __init__(
        self,
        vocab_size: int,
        hidden_dim: int,
        max_lag: int,
        n_rules: int,
        max_seq_len: int,
        conv_kernel: int = 4,
        kappa: float = 1.0,
        lambda_decay: float = 0.03,
        alpha_power: float = 1.2,
        sigma: float = 0.15,
        num_tds_blocks: int = 12,
        padding_idx: Optional[int] = None,
        dropout: float = 0.1,
        embedding_dropout: float = 0.2,
    ):
        super().__init__()
        self.hidden_dim = hidden_dim
        self.max_seq_len = max_seq_len
        self.padding_idx = padding_idx

        self.embedding = nn.Embedding(
            vocab_size, hidden_dim, padding_idx=padding_idx
        )
        self.embedding_dropout = nn.Dropout(embedding_dropout)

        pe = torch.zeros(max_seq_len, hidden_dim)
        pos = torch.arange(max_seq_len).unsqueeze(1).float()
        div_term = torch.exp(
            torch.arange(0, hidden_dim, 2).float()
            * (-math.log(10000.0) / hidden_dim)
        )
        pe[:, 0::2] = torch.sin(pos * div_term)
        pe[:, 1::2] = torch.cos(pos * div_term)
        self.register_buffer("position_encoding", pe)

        self.tds_blocks = nn.ModuleList([
            TDSBlock(
                hidden_dim=hidden_dim,
                max_lag=max_lag,
                n_rules=n_rules,
                conv_kernel=conv_kernel,
                kappa=kappa,
                lambda_decay=lambda_decay,
                alpha_power=alpha_power,
                sigma=sigma,
                expand_factor=2,
                dropout=dropout,
            )
            for _ in range(num_tds_blocks)
        ])
        self.norm_final = nn.LayerNorm(hidden_dim)
        self.lm_head = nn.Linear(hidden_dim, vocab_size, bias=False)
        self.lm_head.weight = self.embedding.weight

    def forward(self, input_ids: torch.Tensor) -> torch.Tensor:
        B, T = input_ids.shape
        T_clamp = min(T, self.max_seq_len)
        input_ids = input_ids[:, :T_clamp]

        x = self.embedding(input_ids)
        x = x + self.position_encoding[:T_clamp].unsqueeze(0)
        x = self.embedding_dropout(x)

        for blk in self.tds_blocks:
            x = blk(x)

        x = self.norm_final(x)
        logits = self.lm_head(x)
        return logits

    @torch.no_grad()
    def generate(
        self,
        prompt_ids: torch.Tensor,
        max_gen_len: int = 64,
        temperature: float = 0.9,
        top_k: int = 0,
    ) -> torch.Tensor:
        """Greedy / temperature / top-k sampling generation."""
        self.eval()
        cur_tokens = prompt_ids.clone()
        for _ in range(max_gen_len):
            seq_len = cur_tokens.shape[1]
            if seq_len >= self.max_seq_len:
                break
            logits = self.forward(cur_tokens)
            next_logit = logits[:, -1, :] / temperature

            if top_k > 0:
                v, _ = torch.topk(next_logit, top_k)
                next_logit[next_logit < v[:, [-1]]] = float("-inf")

            prob = F.softmax(next_logit, dim=-1)
            next_token = torch.multinomial(prob, num_samples=1)
            cur_tokens = torch.cat([cur_tokens, next_token], dim=-1)
        return cur_tokens
