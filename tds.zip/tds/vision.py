"""
Vision TDS model.

A TDS-based image classifier that processes image patches as a token sequence,
similar to a Vision Transformer but with TDS blocks instead of self-attention.
"""

import math
from typing import List

import torch
import torch.nn as nn
from torch.utils.checkpoint import checkpoint

from .core import TDSBlock
from .utils import DropPath


class ConvPatchEmbedding(nn.Module):
    """Convolutional patch stem with total stride 16 -> 14x14 patches."""

    def __init__(self, in_channels: int = 3, hidden_dim: int = 384):
        super().__init__()
        dims = [hidden_dim // 8, hidden_dim // 4, hidden_dim // 2, hidden_dim]
        layers = []
        current_channels = in_channels
        for out_channels in dims:
            layers.extend([
                nn.Conv2d(
                    current_channels,
                    out_channels,
                    kernel_size=3,
                    stride=2,
                    padding=1,
                    bias=False,
                ),
                nn.BatchNorm2d(out_channels),
                nn.GELU(),
            ])
            current_channels = out_channels
        self.proj = nn.Sequential(*layers)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.proj(x)  # [B, H, 14, 14]
        if x.shape[-2:] != (14, 14):
            raise RuntimeError(
                f"Patch stem must output 14x14, received {tuple(x.shape[-2:])}"
            )
        return x.flatten(2).transpose(1, 2)  # [B, 196, H]


class StableTDSLayer(nn.Module):
    """
    External Pre-Norm + LayerScale + DropPath wrapper around a TDSBlock.
    """

    def __init__(
        self,
        hidden_dim: int,
        drop_path: float,
        layer_scale_init: float = 1e-4,
        **tds_kwargs,
    ):
        super().__init__()
        self.pre_norm = nn.LayerNorm(hidden_dim)
        self.tds = TDSBlock(hidden_dim=hidden_dim, **tds_kwargs)
        self.layer_scale = nn.Parameter(torch.ones(hidden_dim) * layer_scale_init)
        self.drop_path = DropPath(drop_path)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x_norm = self.pre_norm(x)
        block_output = self.tds(x_norm)
        delta = block_output - x_norm
        return x + self.drop_path(self.layer_scale.view(1, 1, -1) * delta)


class VisionTDSClassifier(nn.Module):
    """
    VisionTDS for image classification.

    Image -> Conv stem -> patch tokens -> 2D position embedding
          -> TDS layers (optionally with four-direction scans)
          -> final norm -> mean pooling -> classifier head.
    """

    def __init__(
        self,
        img_size: int = 224,
        patch_size: int = 16,
        in_channels: int = 3,
        hidden_dim: int = 384,
        max_lag: int = 10,
        n_rules: int = 6,
        num_classes: int = 1000,
        num_tds_blocks: int = 18,
        conv_kernel: int = 4,
        kappa: float = 1.0,
        lambda_decay: float = 0.03,
        alpha_power: float = 1.2,
        sigma: float = 2.0,
        drop_path_rate: float = 0.2,
        use_checkpoint: bool = True,
        use_four_direction_scan: bool = True,
    ):
        super().__init__()
        if img_size != 224 or patch_size != 16:
            raise ValueError(
                "This model configuration expects img_size=224 and patch_size=16."
            )

        self.hidden_dim = hidden_dim
        self.grid_size = img_size // patch_size
        self.num_patches = self.grid_size ** 2
        self.use_checkpoint = use_checkpoint
        self.use_four_direction_scan = use_four_direction_scan

        self.patch_embed = ConvPatchEmbedding(in_channels, hidden_dim)
        self.pos_embed_2d = nn.Parameter(
            torch.zeros(1, hidden_dim, self.grid_size, self.grid_size)
        )
        self.embed_norm = nn.LayerNorm(hidden_dim)
        self.embed_dropout = nn.Dropout(0.1)

        drop_rates = torch.linspace(0.0, drop_path_rate, num_tds_blocks).tolist()
        self.layers = nn.ModuleList([
            StableTDSLayer(
                hidden_dim=hidden_dim,
                drop_path=drop_rates[i],
                layer_scale_init=1e-4,
                max_lag=max_lag,
                n_rules=n_rules,
                conv_kernel=conv_kernel,
                kappa=kappa,
                lambda_decay=lambda_decay,
                alpha_power=alpha_power,
                sigma=sigma,
                expand_factor=2,
            )
            for i in range(num_tds_blocks)
        ])

        row = torch.arange(self.num_patches, dtype=torch.long)
        grid = row.reshape(self.grid_size, self.grid_size)
        scan_orders = [
            row,
            torch.flip(row, dims=[0]),
            grid.transpose(0, 1).reshape(-1),
            torch.flip(grid.transpose(0, 1).reshape(-1), dims=[0]),
        ]
        for i, order in enumerate(scan_orders):
            self.register_buffer(f"scan_order_{i}", order, persistent=False)
            self.register_buffer(
                f"scan_inverse_{i}", torch.argsort(order), persistent=False
            )

        self.final_norm = nn.LayerNorm(hidden_dim)
        self.head_dropout = nn.Dropout(0.2)
        self.classifier = nn.Linear(hidden_dim, num_classes)

        self._init_weights()

    def _init_weights(self):
        nn.init.trunc_normal_(self.pos_embed_2d, std=0.02)
        nn.init.trunc_normal_(self.classifier.weight, std=0.02)
        nn.init.zeros_(self.classifier.bias)

        for module in self.patch_embed.modules():
            if isinstance(module, nn.Conv2d):
                nn.init.kaiming_normal_(
                    module.weight, mode="fan_out", nonlinearity="relu"
                )
            elif isinstance(module, nn.BatchNorm2d):
                nn.init.ones_(module.weight)
                nn.init.zeros_(module.bias)

    def _run_layer(self, layer, x: torch.Tensor) -> torch.Tensor:
        if self.use_checkpoint and self.training:
            return checkpoint(layer, x, use_reentrant=False, preserve_rng_state=True)
        return layer(x)

    def forward_features(self, x: torch.Tensor) -> torch.Tensor:
        x = self.patch_embed(x)  # [B, 196, H]

        pos = self.pos_embed_2d.flatten(2).transpose(1, 2)
        x = self.embed_norm(x + pos)
        x = self.embed_dropout(x)

        for index, layer in enumerate(self.layers):
            if self.use_four_direction_scan:
                mode = index % 4
                order = getattr(self, f"scan_order_{mode}")
                inverse = getattr(self, f"scan_inverse_{mode}")
                x_scan = x.index_select(1, order)
                x_scan = self._run_layer(layer, x_scan)
                x = x_scan.index_select(1, inverse)
            else:
                x = self._run_layer(layer, x)

        x = self.final_norm(x)
        return x.mean(dim=1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.forward_features(x)
        x = self.head_dropout(x)
        return self.classifier(x)

    def get_patch_features(self, x: torch.Tensor) -> torch.Tensor:
        """Return patch tokens before pooling (useful for VL connector)."""
        x = self.patch_embed(x)
        pos = self.pos_embed_2d.flatten(2).transpose(1, 2)
        x = self.embed_norm(x + pos)
        x = self.embed_dropout(x)

        for index, layer in enumerate(self.layers):
            if self.use_four_direction_scan:
                mode = index % 4
                order = getattr(self, f"scan_order_{mode}")
                inverse = getattr(self, f"scan_inverse_{mode}")
                x_scan = x.index_select(1, order)
                x_scan = self._run_layer(layer, x_scan)
                x = x_scan.index_select(1, inverse)
            else:
                x = self._run_layer(layer, x)

        return self.final_norm(x)
